# Marks the core directory as a Python package.

