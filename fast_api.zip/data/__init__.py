# Marks the data directory as a Python package.

