# This file marks the utils directory as a Python package.
from .FileOperations import FileOperations
from .WebScraper import WebScraper
from .auth import *

